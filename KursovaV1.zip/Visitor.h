#pragma once
#include "MyForm.h"
#include <Windows.h>

using namespace::Visitor;

class Visitor : IVisitor
{
};

